"""
    @author: xuanke
    @time: 2020/5/19
    @function: 模块A
"""

paramsA = 'ok'


def test_a():
    print("test a")
